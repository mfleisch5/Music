package cs3500.music.model;

/**
 * Created by michaelfleischmann on 10/20/16.
 */
public enum Direction {
  Up, Down, Left, Right;
}

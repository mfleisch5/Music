package cs3500.music.model;

/**
 * Created by michaelfleischmann on 12/12/16.
 */
public enum RepeatType {
  Start, Play, End
}
